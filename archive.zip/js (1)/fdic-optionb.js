
const template = document.createElement('template'); 
template.innerHTML = `
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Sans+3:ital,wght@1,400;1,600">
<style>
  .fdic-banner { background: transparent; margin: 0;  padding-top: 0.5rem; color: #1b1b1b;  line-height: 1.5; font-family: "Source Sans Pro Web", "Source Sans 3", sans-serif; font-size: 14px; font-weight: 400;}
  .fdic-icon {  margin-right: 0.5rem;  padding-top: 0;  float: left;  border-style: none;  box-sizing: inherit;}
  .fdic-headliner {  display: flex;  flex-wrap: nowrap;  align-items: center;  max-width: 1388px;  margin-left: 0;  margin-right: auto;  padding: 4px; cursor: pointer; position: relative;}
  .fit-auto {  display: block;  flex: 0 0 auto;  width: auto;  max-width: 100%;  position: relative;  box-sizing: border-box; margin-right: 0.3rem;}
  .fdic-header-text {  display: block;  font-family: "Source Sans Pro Web", "Source Sans 3", sans-serif;  font-style: italic; margin-left: 0.2em;  margin-top: 1em;  line-height: 1.1; }
  .linkimg {  display: block;  width: 2.5rem;  float: left;}
  .grid-row {  margin-left: -0.75rem;  margin-right: -0.75rem;  display: flex;  flex-wrap: wrap;  box-sizing: inherit;}
  .gov-ban-notice {  display: flex;  flex: 0 0 auto;  flex-direction: row;  align-items: flex-start;  padding-left: 1rem !important;  padding-right: 1rem !important;  width: 48%;  margin: 0rem -1rem;}
  .accordion-button {  display: inline-block;  margin: 0;  padding: .2rem;  border: 0;  background-color: transparent;  cursor: pointer;}
  #fdic-icon { width: 62px;  margin: 0.25em; margin-right: 0.5em;}
  #expander { display: block; width: 1em; margin: 7px; }
  #expander.flipped { transform: rotate(3.142rad); }
  svg.lowersvg {width: 40px; margin-top: 15px; margin-left: 25px;}
  hr { width: 90%; }
  .fdic-banner.white { color: #fff; font-weight: 600;}
  .blue svg {  fill: #003256;}
  .white svg {  fill: #fff;}
  .white p, .white a, .white div {  color: #fff;}
</style>
<div class="fdic-banner">
  <div class="fdic-headliner" id="fdic-top-part">
      <svg id="fdic-icon" data-name="fdic-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 712 300">
        <title>FDIC logo</title>
        <polygon class="letter" points="71.02 67.24 71.02 112.79 148.74 112.79 148.74 172.8 71.02 172.8 71.02 279.8 0.17 279.8 0.17 7.23 156.7 7.23 156.7 67.24 71.02 67.24"/>
        <path class="letter" d="M179.88,13.85V286.41h70.51l.34-60V73.85h16.63c45.55,0,77.72,27.48,77.72,76.28,0,53.14-36.15,76.28-78.44,76.28H250.73l-.34,60h30c75.56,0,138.46-59.64,138.46-136.28S356.29,13.85,280.37,13.85Z" transform="translate(-9.88 -6.62)"/>
        <rect class="letter" x="419.03" y="7.23" width="70.85" height="272.57"/>
        <path class="letter" d="M718,105.31c-14.46-19.53-38-30-62.17-30-43.38,0-72.66,33.26-72.66,75.55,0,43,29.64,74.11,73.74,74.11C680,225,703.16,213.75,718,196v85c-23.49,7.23-40.48,12.65-62.54,12.65-38,0-74.1-14.46-102.3-40.12-30-27.11-43.74-62.54-43.74-103a142.64,142.64,0,0,1,40.13-99.77C576.28,23.25,615,6.62,653.28,6.62c22.77,0,43.74,5.06,64.7,13.73Z" transform="translate(-9.88 -6.62)"/>
      </svg>
      <p class="fdic-header-text">FDIC-Insured - Backed by the full faith and credit of the U.S. Government</p>        
      <svg id="expander" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 39">
        <title>Click for details</title>
        <path d="M63.36 4.004L60.155.741c-.427-.436-.919-.654-1.475-.654-.555 0-1.047.218-1.475.654L32 26.4 6.798.74C6.37.306 5.878.088 5.323.088c-.556 0-1.048.218-1.476.654L.642 4.005C.213 4.44 0 4.941 0 5.507c0 .565.214 1.066.642 1.501l29.883 30.427c.427.435.92.652 1.475.652.556 0 1.047-.217 1.474-.652L63.361 7.008c.427-.435.639-.936.639-1.501 0-.566-.212-1.067-.64-1.503z"/>
      </svg>
      <div id="output"></div>
  </div>
  <div class="fdic-accordion" id="fdic-expand" hidden="">
    <div class="grid-row">
      <div class="gov-ban-notice">
        <div style="width:140px">
            <a id="imgBankfind" href="">
            <svg class="lowersvg" version="1.0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
              <title>FDIC Bank Find Suite</title>
              <path d="M35.726 0.093A37.921 37.921 0 0 0 2.693 24.044C1.529 26.984 0.774 29.94 0.323 33.364c-0.17 1.257 -0.187 1.801 -0.187 4.614 -0.009 3.441 0.085 4.495 0.595 7.179 2.762 14.426 13.756 26.066 27.986 29.609 6.891 1.716 14.146 1.496 20.832 -0.645 3.373 -1.079 6.856 -2.762 9.635 -4.656l0.832 -0.569 0.179 0.196c0.102 0.11 5.99 6.908 13.084 15.106s13.092 15.115 13.322 15.353c0.238 0.246 0.569 0.493 0.731 0.544 0.442 0.144 1.274 0.034 2.005 -0.272 0.807 -0.332 2.37 -1.368 3.526 -2.337 1.257 -1.054 3.585 -3.398 4.409 -4.444 1.368 -1.725 2.303 -3.322 2.549 -4.358 0.153 -0.645 0.119 -1.41 -0.085 -1.826 -0.153 -0.315 -2.71 -2.566 -15.403 -13.543 -8.368 -7.238 -15.25 -13.22 -15.293 -13.279 -0.051 -0.068 0.144 -0.433 0.621 -1.147 4.791 -7.154 6.975 -16.083 6.074 -24.834 -1.224 -11.888 -7.969 -22.483 -18.25 -28.66C51.003 1.503 43.339 -0.365 35.726 0.093zm4.97 9.176c10.774 0.977 20.213 8.097 24.163 18.232 2.014 5.157 2.49 10.679 1.402 16.126 -0.493 2.464 -1.173 4.511 -2.26 6.755 -1.011 2.107 -1.921 3.585 -3.288 5.353 -0.798 1.028 -2.897 3.212 -4.002 4.163 -4.215 3.611 -9.303 5.871 -15.038 6.686 -1.546 0.213 -5.803 0.221 -7.35 0 -5.463 -0.774 -10.213 -2.803 -14.401 -6.151 -1.071 -0.858 -3.22 -2.965 -4.095 -4.019 -3.458 -4.163 -5.684 -9.261 -6.44 -14.784 -0.196 -1.385 -0.263 -4.461 -0.136 -5.956 0.493 -5.82 2.643 -11.223 6.262 -15.752 0.943 -1.173 3.212 -3.458 4.325 -4.342 3.806 -3.042 7.986 -5.004 12.557 -5.888 2.923 -0.569 5.361 -0.688 8.301 -0.425z"/>
              <path d="m27.995 20.255 -9.601 5.642 -0.026 0.645 -0.026 0.645H57.017l-0.026 -0.654 -0.026 -0.645 -9.601 -5.642c-5.276 -3.092 -9.635 -5.633 -9.685 -5.633 -0.043 0 -4.401 2.54 -9.685 5.642zm10.934 -1.283c0.679 0.306 1.266 0.884 1.563 1.529 0.221 0.468 0.246 0.621 0.246 1.334s-0.026 0.858 -0.238 1.274c-0.332 0.645 -0.918 1.215 -1.538 1.503 -0.45 0.204 -0.621 0.238 -1.283 0.238 -0.654 0 -0.832 -0.034 -1.249 -0.229a3.221 3.221 0 0 1 -1.538 -1.503c-0.246 -0.501 -0.272 -0.629 -0.272 -1.326 0 -0.645 0.034 -0.832 0.221 -1.24a3.277 3.277 0 0 1 1.971 -1.742c0.561 -0.187 1.538 -0.11 2.115 0.162zM20.815 30.332v1.104h0.85v14.002l-0.221 0.051c-0.119 0.034 -0.315 0.162 -0.425 0.28 -0.196 0.213 -0.204 0.272 -0.204 1.309v1.096h33.832l-0.026 -1.054c-0.034 -1.19 -0.153 -1.47 -0.662 -1.615l-0.263 -0.076V31.436h0.934v-2.209H20.815v1.104zm7.902 8.105v7.001l-0.246 0.06c-0.315 0.068 -0.526 0.297 -0.595 0.654l-0.06 0.28 -0.688 0.026 -0.679 0.026 -0.051 -0.238c-0.068 -0.349 -0.365 -0.679 -0.654 -0.748l-0.255 -0.06V31.436h3.228v7.001zm7.052 0.009c0 6.882 0 7.009 -0.162 7.009 -0.263 0 -0.612 0.357 -0.679 0.679l-0.06 0.297 -0.688 0.026 -0.688 0.026 -0.06 -0.255c-0.076 -0.365 -0.34 -0.662 -0.638 -0.731l-0.255 -0.06V31.436h3.228v7.009zm7.052 0c0 6.78 -0.009 7.009 -0.162 7.009 -0.263 0 -0.595 0.332 -0.688 0.688l-0.093 0.332h-1.334l-0.06 -0.255c-0.076 -0.357 -0.349 -0.654 -0.638 -0.722l-0.255 -0.06V31.436H42.821v7.009zm7.052 0c0 6.78 -0.009 7.009 -0.162 7.009 -0.255 0 -0.595 0.323 -0.697 0.688l-0.102 0.332h-1.317l-0.06 -0.255c-0.076 -0.357 -0.349 -0.654 -0.638 -0.722l-0.255 -0.06V31.436h3.228v7.009zM18.012 51.912v1.785h39.338V50.128H18.012v1.785z"/>
            </svg>
            </a>
        </div>
        <p>                  
          <a id="lblBankfind" href=""><strong>BankFind</strong></a>
          <br>
          This bank is insured by the Federal Deposit Insurance Corporation. The FDIC Certificate ID is <u><a id="cert" href=""></a></u>. Click on the Certificate ID # to confirm this bank's FDIC coverage using the FDIC's BankFind tool.          
        </p>
      </div>
      <div class="gov-ban-notice">       
        <div style="width:140px; margin-right:0.5rem">
          <a href="https://edie.fdic.gov/">
          <svg class="lowersvg" version="1.0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 108">
            <title>Electronic Deposit Insurance Estimator</title>
            <path d="M49.241 0.132c-0.782 0.179 -1.056 0.302 -2.356 1.084 -1.442 0.867 -5.023 2.658 -7.398 3.704 -10.319 4.542 -24.031 8.614 -34.351 10.197 -0.829 0.132 -1.696 0.302 -1.932 0.386 -1.282 0.452 -2.45 1.583 -2.874 2.771 -0.283 0.801 -0.32 1.461 -0.226 3.939 0.386 10.913 2.149 22.901 4.891 33.314 7.181 27.189 20.959 44.793 40.024 51.154 3.986 1.319 5.136 1.489 7.049 0.999 7.615 -1.951 14.843 -5.834 20.724 -11.139 0.509 -0.462 1.065 -0.952 1.235 -1.093l0.302 -0.264 0.98 0.509c2.102 1.093 3.883 1.574 6.484 1.753 6.889 0.452 13.09 -3.176 16.04 -9.377 0.858 -1.809 1.319 -3.591 1.498 -5.739 0.424 -5.249 -2.356 -11.3 -6.672 -14.523 -0.631 -0.462 -0.858 -0.688 -0.82 -0.792 1.809 -4.684 3.854 -11.799 5.183 -18.009 1.932 -9.028 3.27 -20.186 3.364 -28.037 0.019 -1.498 0 -1.885 -0.151 -2.356 -0.415 -1.395 -1.489 -2.545 -2.893 -3.072 -0.264 -0.104 -1.169 -0.292 -1.998 -0.415C85.024 13.542 71.275 9.462 60.974 4.919c-2.431 -1.074 -5.758 -2.742 -7.398 -3.704 -0.726 -0.424 -1.574 -0.858 -1.875 -0.952 -0.754 -0.236 -1.762 -0.292 -2.46 -0.132zm3.421 11.252c9.565 4.778 23.466 9.462 35.256 11.893 1.272 0.264 2.422 0.499 2.545 0.528l0.226 0.047 -0.066 1.056c-0.311 5.174 -1.112 11.865 -2.036 17.076 -0.707 3.939 -1.828 9.141 -1.97 9.057 -0.028 -0.019 -0.198 0.518 -0.377 1.197 -0.829 3.289 -2.394 8.34 -3.525 11.375l-0.396 1.084 -0.98 0.113c-2.639 0.311 -4.872 1.065 -6.964 2.365 -3.911 2.431 -6.559 6.286 -7.483 10.875 -0.283 1.423 -0.311 4.213 -0.047 5.447 0.245 1.14 0.594 2.356 0.971 3.374l0.33 0.867 -0.688 0.763c-2.168 2.403 -6.493 5.485 -10.348 7.36 -2.535 1.235 -5.994 2.479 -6.88 2.479s-4.345 -1.244 -6.88 -2.479c-2.959 -1.442 -5.947 -3.412 -8.482 -5.57 -1.828 -1.564 -5.457 -5.56 -7.36 -8.114 -5.607 -7.511 -10.272 -18.028 -13.288 -29.94 -0.17 -0.679 -0.349 -1.216 -0.377 -1.197 -0.141 0.085 -1.263 -5.117 -1.97 -9.057 -0.924 -5.212 -1.725 -11.903 -2.036 -17.076l-0.066 -1.056 0.226 -0.047c0.123 -0.028 1.272 -0.264 2.545 -0.528 11.808 -2.431 26.001 -7.228 35.19 -11.874 1.301 -0.66 2.394 -1.206 2.431 -1.206 0.047 -0.009 1.169 0.528 2.497 1.187zm39.647 63.603c0.81 0.763 1.489 1.48 1.527 1.602 0.038 0.16 -0.019 0.302 -0.17 0.471 -0.547 0.613 -11.431 12.053 -11.563 12.157 -0.368 0.302 -0.509 0.179 -3.421 -2.874 -1.574 -1.64 -3.204 -3.346 -3.628 -3.788s-0.801 -0.905 -0.839 -1.018c-0.057 -0.198 0.123 -0.415 1.423 -1.725C76.806 78.635 77.183 78.314 77.372 78.314s0.415 0.179 0.905 0.679c0.358 0.377 1.291 1.357 2.073 2.168l1.423 1.489 3.572 -3.732c1.96 -2.054 3.911 -4.09 4.326 -4.524 0.518 -0.547 0.82 -0.792 0.971 -0.792 0.141 0 0.679 0.443 1.668 1.385z"/>
            <path d="M46.649 22.618v4.052l-0.254 0.057c-2.102 0.481 -3.383 0.914 -4.835 1.64 -2.526 1.263 -4.599 3.185 -5.956 5.494 -1.809 3.101 -2.384 7.709 -1.348 10.97 1.244 3.939 4.231 6.719 10.602 9.848 1.169 0.575 3.185 1.564 4.476 2.196 2.799 1.385 4.128 2.224 5.23 3.336 1.244 1.244 1.687 2.365 1.564 3.92 -0.226 3.035 -2.102 4.608 -5.73 4.835 -4.071 0.245 -7.681 -0.876 -12.119 -3.77 -0.631 -0.424 -1.169 -0.745 -1.187 -0.726 -0.405 0.518 -5.334 7.737 -5.334 7.803 0 0.123 1.414 1.178 2.45 1.838 2.837 1.791 7.162 3.364 10.885 3.958 0.518 0.085 1.084 0.179 1.253 0.207l0.302 0.047V86.231h8.199l0.019 -4.118 0.028 -4.118 0.895 -0.217c6.729 -1.64 10.932 -5.777 12.082 -11.884 0.311 -1.64 0.311 -4.467 0 -5.852 -0.547 -2.422 -1.48 -4.165 -3.214 -5.975 -2.224 -2.318 -4.835 -3.902 -10.941 -6.616 -4.929 -2.196 -6.861 -3.506 -7.643 -5.174 -0.509 -1.093 -0.452 -2.667 0.141 -3.977 0.509 -1.103 1.8 -2.017 3.355 -2.365 1.008 -0.226 3.723 -0.236 4.769 -0.009 2.158 0.471 4.052 1.432 6.145 3.119l0.782 0.631 0.773 -0.81c0.424 -0.452 1.847 -1.951 3.148 -3.327l2.384 -2.507 -0.641 -0.603c-3.251 -3.101 -7.172 -5.108 -11.281 -5.786l-0.754 -0.123 -0.028 -3.977 -0.019 -3.977h-8.199v4.052z"/>
          </svg>
          </a>
        </div>
        <p><a href="https://edie.fdic.gov/"> <strong>EDIE</strong></a>
          <br>
          EDIE lets consumers and bankers know, on a per-bank basis, how the insurance rules and limits apply to a depositor's accounts-what's insured and what portion (if any) exceeds coverage limits at that bank. <a href="https://edie.fdic.gov/"> <u>Check your deposit insurance coverage</u> >></a>
        </p>
      </div>
    </div>
    <hr>
  </div>
</div>
</div>
`;

class FDICoptionB extends HTMLElement {
    constructor(){
        super();     
        this.showInfo = false; 

        this.root = this.attachShadow({mode:'closed'});        
        let clone = template.content.cloneNode(true);
        this.root.append(clone);

        // Cert and Color attributes moved to connecteCallback, because they stopped working here.
        let insureflag = true;
        
        // For the uninsured:
        if (!insureflag) {
          //update the banner text with uninsured text 
          let textline = this.root.querySelector('p.usa-banner__header-text');
          textline.innerHTML = "<strong>Products offered on this page are Not FDIC Insured, Not Deposits, and May Lose Value.</strong>";

          //hide FDIC logo when uninsured 
          let logo = this.root.querySelector('img.usa-banner__header-flag');
          logo.style.display = 'none';
        }
    }     

    toggleInfo(){      
      this.showInfo = !this.showInfo;

      const info = this.root.querySelector('#fdic-expand');
      const button = this.root.querySelector('#expander');
      button.classList.toggle('flipped');

      if (this.showInfo){
        info.style.display = 'block';                
      }else {
        info.style.display = 'none';
      }

    }

    connectedCallback(){      
      this.root.querySelector('#fdic-top-part').addEventListener('click', ()=>{
        this.toggleInfo();
      });

      let cert = this.getAttribute('cert');
      let color = this.getAttribute('color');
      if (cert != undefined){
        let clean = cert.replace(/\D/g, ''); // Only allow characters of the range 0-9
        cert = clean;
        let bankURL = "https://banks.data.fdic.gov/bankfind-suite/bankfind/details/" + clean;
        let certHTML = this.root.querySelector('#cert');
        certHTML.href = bankURL;
        certHTML.innerHTML = clean;

        let imgBankfind = this.root.querySelector('#imgBankfind'); 
        imgBankfind.href = bankURL;
        let lbf = this.root.querySelector('#lblBankfind'); 
        lbf.href = bankURL;
      }

      /* Add campaign tracking */
      let analytString = "?utm_source=" + cert + "&utm_medium=wc&utm_campaign=ds";
      var allLinks = this.root.querySelectorAll('a');  // returns a NodeList
      var linkArray = [...allLinks];  // Convert the NodeList to an Array
      linkArray.forEach(lnk => {
        lnk.href = lnk.href + analytString;
      })

      let fdicb = this.root.querySelector('.fdic-banner');
      if (color != undefined){
        if (color == 'white') {
          fdicb.classList.add('white');
        } else {
          // Didnt specify white, default to blue coloration
          fdicb.classList.add('blue');
        }
      } else {
        // No color flag present, default to blue coloration
        fdicb.classList.add('blue');
      }
    }

}

//define the class with the custom HTML element 
window.customElements.define('fdic-optionb', FDICoptionB);